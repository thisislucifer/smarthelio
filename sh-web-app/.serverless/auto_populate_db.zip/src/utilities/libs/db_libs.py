from sqlalchemy import and_
from sqlalchemy import join
from sqlalchemy.pool import QueuePool
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
# try:
#     import psycopg2
#     import psycopg2.extras
# except ImportError:
#     pass

from sqlalchemy import and_, join, outerjoin

from src.utilities.database.db_models import *

#check and create table if doesnot exists ->
# ActivityLogs.check_table()
# Product.check_table()
# VendorType.check_table()
# ItemType.check_table()
# ItemSubType.check_table()
# Item.check_table()
# Vendor.check_table()
# VendorShippingDetails.check_table()
# VendorContactDetails.check_table()