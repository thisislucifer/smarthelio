import json
from src.utilities.modules.sensor.operations import SensorOps
from src.utilities.libs.common_libs import *
from src.utilities.responses.responses import *
from src.utilities.database.db_models import *

# create database engine and conn - 
# db_obj = DatabaseEngine()
# conn = db_obj.get_db_connection()
# cur = db_obj.get_db_cursor(conn)
db_ops = DatabaseEngine()
session = db_ops.get_db_session()


def list_s(event,context):
    try:
        obj = SensorOps(session)
        sensors = obj.list_sensors()
        return success_response("Data retrieved successfully", sensors)
    except Exception as e:
        return error_response("Data not retrieved successfully",500)